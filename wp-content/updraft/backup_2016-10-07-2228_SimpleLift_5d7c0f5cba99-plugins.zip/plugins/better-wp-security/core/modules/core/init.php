<?php

ITSEC_Modules::register_module( 'core', dirname( __FILE__ ), 'always-active' );
