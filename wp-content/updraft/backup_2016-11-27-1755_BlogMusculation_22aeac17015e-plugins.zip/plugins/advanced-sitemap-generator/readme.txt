=== Advanced Sitemap Generator ===
Contributors: sparxit 
Tags: sitemap, simple sitemap, page sitemap, exclude category posts, posts sitemap, sitemap shortcode, shortcode
Requires at least: 2.9.1
Tested up to: 3.9.1
Stable tag: 1.1.1

This plugin easily display you post and page through shortcode on front end.You just need to put shortcode([sitemap]) on your page or post.

== Description ==
<p> This plugin is the most powerfull plugin which easily display your post and page through shortcode on front end.You just need to put shortcode([sitemap]) on your page/post. </p>
<p> If you want to exclude pages then put ([sitemap excludepage="1,4"])	where 1,4 are the page id seperated by the comma's. </p>
<p> If you want to exclude  post from a specific categories then put ([sitemap	excludepage="1,4" excludecat="6,3"]) where 6,3 are the category id seperated by the comma's. </p>
<p> If you want to exclude specific posts then put ([sitemap excludepage="1,4" excludecat="6,3" excludepost="1,183"]) where 1,183 are the post id seperated by the comma's. </p>
<p> If you want to show custom link "home" then put ([sitemap excludepage="1,4" excludecat="6,3" excludepost="1,183" home="yes"]) </p>
<p> If you want to show specific number of post then put ([sitemap excludepage="1,4" excludecat="6,3" excludepost="1,183" home="yes" postcount="4"]) where 4 is the number of post to show </p>
<p> If you don't want to show any of the post put ([sitemap showpost="no"]) </p>
<p> For more plugins, themes and WordPress support , Please visit http://www.csschopper.com/ </p>


== Installation ==

Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.

put shortcode([sitemap]) on your page/post on backend. for more details go to setting page of plugin on admin panel.

== Screenshots ==

1. screenshot-1.jpg
2. screenshot-2.jpg
