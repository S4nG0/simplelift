<?php exit; ?>
[2016-10-07 22:52:52] WARNING: Form 70 > *************t@hotmail.fr is already subscribed to the selected list(s)
