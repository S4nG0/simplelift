<?php

ITSEC_Modules::register_module( 'wordpress-salts', dirname( __FILE__ ), 'always-active' );
