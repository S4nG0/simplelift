Wallstreet.

WallStreet is a Business WordPress Theme that contains a lot of features for customizing your website as you need. Already thousands of users loving this theme because it is designed for multiple businesses like corporates, firms, law firms, digital media agency, architecture firm, personal, portfolio and freelancer's website. The theme is developed using Bootstrap 3 CSS framework that makes it friendly for all the devices like mobiles, tablets, laptops etc. In WallStreet Lite, you can easily set Featured Banner / Slide, Social Icons in Header, Contact Information, Services, Portfolio, 4 column widgetized footer. Couple of page templates are added one is Homepage and the second one is full width page template. In the premium version, you will get 2 color skins Lite and Dark, 10 predefined color schemes, feature for creating your custom color scheme, an eye-catching slider, Services, Testimonial’s, Portfolio, Clients/ Sponsors, Blog Layouts, Layout Manager and Latest News. You will get Various page templates  like About, Service, Portfolio, Blog and Contact Us. The theme has supports for popular  plugins like WPML, Polylang and JetPack Gallery Extensions. Just navigate to Appearance > Customize to start customizing. Both the lite and premium version of WallStreet themes are completely translated in Spanish Language. Check premium version theme demo at http://webriti.com/demo/wp/wallstreet000000000000000000000000000000000000000000000000000000000000000000000000000000000


Author: Priyanshu Mittal,Shahid Mansuri and Harish Lodha.
Theme Homepage Url:http://webriti.com/demo/wp/wallstreet/

About:
wallstreet a theme for business, consultancy firms etc  by Webriti (Author URI: http://www.webriti.com). 

The CSS, XHTML and design is released under GPL:
http://www.opensource.org/licenses/gpl-license.php

Feel free to use as you please. I would be very pleased if you could keep the Auther-link in the footer. Thanks and enjoy.
Wallstreet supports Custom Menu, Widgets and 
the following extra features:

 - Pre-installed menu and content colors
 - Responsive
 - Custom sidebars
 - Support for post thumbnails
 - Similar posts feature
 - 4 widgetized areas in the footer
 - Customise Front Page 
 - Custom footer
 - Translation Ready 
 

# Basic Setup of the Theme.
-----------------------------------
Fresh installation!

1. Upload the wallstreet Theme folder to your wp-content/themes folder.
2. Activate the theme from the WP Dashboard.
3. Done!
=== Images ===

All images in wallstreet-Pro are licensed under the terms of the GNU GPL.

# Top Navigation Menu:
- Default the page-links start from the left! Use the Menus function in Dashboard/Appearance to rearrange the buttons and build your own Custom-menu. DO NOT USE LONG PAGE NAMES, Maximum 14 letters/numbers incl. spaces!
- Read more here: http://codex.wordpress.org/WordPress_Menu_User_Guide

===========Front Page Added with the theme=================
1 It has header(logo + menus),Home Featured Image, services,recent comments widgets and footer.

======Site Title and Description=============
Site Title and its description in not shown on home page besides this both are used above each page / post along with the search field.
	
Support
-------
Do you enjoy this theme? Send your ideas - issues - on the theme formn . Thank you!
@Version 1.6.8
1. Update Theme URI.
@Version 1.6.7
1. Change theme Description.
2. Update theme tags.
@Version 1.6.6
1. Update Theme URI.
@Version 1.6.5
1. Update Style.css File for tags not showing on wordpress.org
@Version 1.6.4.8
1. Change Theme Description Priority.
@Version 1.6.4.7
1. Small change in style.css file.
@Version 1.6.4.6
1.Added new spanish language translations files.
@Version 1.6.4.5
1.Change blog post meta class and blog post author.
@Version 1.6.4.4
1. Update Font Awesome Icon 4.6.1 to 4.6.3
2. Add Theme Support Title Tag.
@Version 1.6.4.3
1. Update Style.css
2. Add Default.css File.
@Version 1.6.4.2
1.  Adding full width page template
2.  Remove page title and meta from page.php and fullwidth.php
@Version 1.6.4.1
1.  Added Spanish Translation
@Version 1.6.4
1. Change Service & Banner Image.
2. Update Font awesome Icon 4.4.0 to 4.5.0
@Version 1.6.3
1. Change Pagetitle-separator styling image to css.
@Version 1.6.2
1. Recommanded Install Facebood Feed Plugin.
2. Remove Add theme Support title Tag.
@Version 1.6.1
1. Solve Theme Check Error.
@Version 1.6
1. Add Pro Feature in Customizer for Demo Purpose.
2. Add Screen Reader Css.
3. Add Google Font.
4. Update Font Awesome Folder.
@Version 1.5.3
1. Fixed for blank values in portfolio/project item images.
@Version 1.5.2
1. Fixed Project title saving issue.
@Version 1.5.1
1. Changed sidebar post widget link from blue to green.
@Version 1.5
1. Footer copyright setting issue resolved.
@Version 1.4
1. Added Customizer.
@Version 1.3
1. Add Blog section in front-page.
@Version 1.2 
1. Remove resize image option.
2. Fixed Styling issue.
@Version 1.1
1. Removed plugin territory code. ie social icons removed from the user account.
2. Removed extra check code for option settings.
@version 1.0
1. Add Theme URI.

@version 0.7
1. Fixed header cannot modified by removing the extra white spaces from the woocommerce.php file.
@version 0.6
1. Removed the undefined idex errors from the project , service and slider settings.
@version 0.5
1. Fixed minor bug related to undefined index error!!
@Version 0.4.4
1. Added translation ready tag.
@version 0.4.3
Removed translation-ready tag
@version 0.4.2
1. Added text domain to untranslated strings.
2. Removed the unused resource bootstrap.map.css
3. Updated Pot file.
@version 0.4.1
1. Update all the default social links to #
2. Add prefix to all the registered custom scripts.
3. Added woocommerce support.
4. Add translation for option panel page and menu title.
@version 0.4
1. the_title replaced with get_search_query in search.php
@version 0.3.3
1. Removed Undefined errors.
@version 0.3.2
1. Remove front-page.php created a template Custom Front Page instead.
2. All the date box linked with this respective post permalink, which provides a way for post without title.
3. Support for long title in post/page.
4. Breadcrumbs issue fixed.
@version 0.3.1
1. Option panel scripts properly enqueued only in the option panel pages
2. MOnster widgets styles fixed
3. No debug errors i found
4. Page title corrected with proper seperator.
5. page for posts called correctly
@Version 0.3
1. Service and portfolio issue fixed.
2. option Panel CSS issue fixed.
3. Remove meta tag from header.php.
4. Add text domain wherever required.
5. Added missing *(star) in all templates.
6. All GPL image added.

@Version 0.2
1. wp_link_pages called within the loop after the content.
2. Always make footer credit link visible only on front page. On the other templates only the text is displayed.
3. Removed default widgets and also managed layout accordingly widgets.
4. Recommended code quality improvement in index-service.php file, index-portfolio.php and index-static-banner.php file.
5. remove all inline css from all templates.
6. Remove custom jquery.
7. Called esc_attr_e wherever required.
8. Called home_url instead of get_bloginfo in breadcrumb.php file.

@Version 0.1
released

Wallstreet WordPress Theme, Copyright 2014 Priyanshu Mittal
Wallstreet is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see .


Wallstreet WordPress Theme bundles the following third-party resources:

Screenshot: Image used in screenshot By Andrew Ruiz
URL: https://unsplash.com/photos/bI2j1olMXUA/download
Source: http://unsplash.com
License: GPL

Portfolio Image
1. https://pixabay.com/en/person-human-girl-female-face-1041904/ 
2. https://pixabay.com/en/rescue-helicopter-red-aircraft-922465/
3. https://pixabay.com/en/norway-mountain-sky-blue-water-772991/
4. https://pixabay.com/en/dress-girl-beautiful-woman-hands-864107/
Source:http://pixabay.com
LIcense: CC0 Public Domain

Service Image
1. https://pixabay.com/en/cop-policewoman-colleagues-funny-1016218/
2. https://pixabay.com/en/veterinarian-animals-funny-1050812/
Source:pixabay.com
License: CC0 Public Domain

Slider Image
URL: https://unsplash.com/photos/bI2j1olMXUA/download
Source: http://unsplash.com
License: GPL

Page Header Image
Source:http://pixabay.com
LIcense: CC0 Public Domain


Font Awesome 4.5.0 by @davegandy - http://fontawesome.io - @fontawesome
License - http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)
Source: http://fontawesome.io

Bootstrap v3.1.1 (http://getbootstrap.com) Copyright 2011-2014 Twitter, Inc.
Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
Source: http://getbootstrap.com
	
List Of Roboto Fonts Used:
1 Roboto Regular
2 Roboto Black
3 Roboto Light
4 Roboto Medium
5 Roboto Thin

Roboto Fonts: http://www.google.com/fonts/specimen/Roboto) by Christian Robertson
Licensed under the [Apache License 2.0](http://www.apache.org/licenses/LICENSE-2.0.html

# --- EOF --- #